#include<vector>
#include<map>
#include<iostream>
using namespace std;



class Added_class{
    public:
        static vector<int> set_acces;
        static map<int,int> freq_map;
        static vector<int> set_cur_length;
};

class tag_directory_new{
    public:
        static std::vector<std::vector<std::pair<uint64_t, pair<int, bool>>>> tag_direc;

    
};


